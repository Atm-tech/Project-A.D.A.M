from sqlalchemy import Column, Integer, String, Numeric, Boolean, DateTime, func
from app.models.base import Base


class PKBProduct(Base):
    __tablename__ = "pkb_products"

    pkb_id = Column(Integer, primary_key=True, index=True)
    barcode = Column(String(50), unique=True, nullable=False, index=True)
    supplier_name = Column(String(150), nullable=False)
    hsn_code = Column(String(20), nullable=False)

    division = Column(String(100), nullable=False)
    section = Column(String(100), nullable=False)
    department = Column(String(100), nullable=False)

    article_name = Column(String(255), nullable=False)
    item_name = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)

    brand_name = Column(String(150), nullable=False)
    size = Column(String(100), nullable=False)

    rsp = Column(Numeric(10, 2), nullable=False)
    mrp = Column(Numeric(10, 2), nullable=False)

    cgst = Column(Numeric(10, 2))
    sgst = Column(Numeric(10, 2))
    cess = Column(Numeric(10, 2))
    igst = Column(Numeric(10, 2))
    tax = Column(Numeric(10, 2))

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)
