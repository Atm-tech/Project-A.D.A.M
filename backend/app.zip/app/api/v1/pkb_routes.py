from fastapi import APIRouter, Depends, File, UploadFile, HTTPException, status
from sqlalchemy.orm import Session

from app.deps import get_db
from app.services.pkb_service import import_pkb_from_excel

router = APIRouter()


@router.post(
    "/upload-excel",
    summary="Upload PKB master as Excel",
    tags=["PKB"],
)
async def upload_pkb_excel(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Upload a PKB Excel file.

    - Reads the file
    - Runs PKB intelligence engine
    - Returns stats: inserted / updated / duplicates / skipped / errors
    """
    # Basic content-type guard (not too strict, Excel MIME types vary)
    if not file.filename.lower().endswith((".xlsx", ".xlsm", ".xltx", ".xltm")):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only Excel (.xlsx / .xlsm / .xltx / .xltm) files are allowed",
        )

    content = await file.read()
    if not content:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Empty file uploaded",
        )

    try:
        result = import_pkb_from_excel(content, db)
    except Exception as e:
        # You can log the real error via logging instead of exposing it
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error while processing PKB Excel: {e}",
        )

    return result
