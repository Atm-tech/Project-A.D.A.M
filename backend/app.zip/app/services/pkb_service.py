from io import BytesIO
from typing import Any, Dict

from openpyxl import load_workbook
from sqlalchemy import inspect
from sqlalchemy.orm import Session

from app.models.pkb import PKBProduct
from app.models.purchase import PKBUpdateLog  # PKBUpdateLog lives in purchase.py (Option B)
from app.utils.text_cleaner import normalize_name, normalize_barcode
from app.utils.weight_parser import parse_weight


def _normalize_header(h: Any) -> str:
    """Normalize Excel header → snake_case-ish key."""
    if not h:
        return ""
    return str(h).strip().lower().replace(" ", "_")


def _log_update(
    db: Session,
    pkb_id: int,
    field: str,
    old_value: Any,
    new_value: Any,
    reason: str = "FIELD_CHANGED",
):
    """Insert a row into PKBUpdateLog."""
    log = PKBUpdateLog(
        pkb_id=pkb_id,
        field_name=field,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(new_value) if new_value is not None else None,
        reason=reason,
    )
    db.add(log)


def import_pkb_from_excel(file_bytes: bytes, db: Session) -> Dict[str, Any]:
    """
    Full PKB Intelligence Engine.

    Business Rules:
    --------------
    A) CASE A – Exact match (barcode + all tracked fields same) → no update
    B) CASE B – Same barcode but any field differs → update row + log field-level changes
    C) CASE C – New barcode, but article_name (clean) matches existing → create NEW PKBProduct + log "duplicate_of"
    D) New product – New barcode + new article_name → insert

    Returns stats dict.
    """

    wb = load_workbook(filename=BytesIO(file_bytes), data_only=True)
    sheet = wb.active

    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        return {
            "inserted": 0,
            "updated": 0,
            "case_c_created": 0,
            "case_a_skipped": 0,
            "errors": 1,
            "total_rows": 0,
            "message": "Empty Excel sheet",
        }

    # HEADER
    header_row = rows[0]
    headers_norm = [_normalize_header(h) for h in header_row]

    # Get actual SQLAlchemy column names on PKBProduct
    mapper = inspect(PKBProduct)
    model_columns = {c.key for c in mapper.attrs}

    inserted = 0
    updated = 0
    case_c_created = 0
    skipped_case_a = 0
    errors = 0

    # Pre-load all PKB rows in memory (for matching)
    all_pkb = db.query(PKBProduct).all()
    barcode_map = {p.barcode: p for p in all_pkb if p.barcode}
    name_map = {normalize_name(p.article_name): p for p in all_pkb if p.article_name}

    # Process each data row
    for row in rows[1:]:
        # Skip completely empty rows
        if all(cell is None or str(cell).strip() == "" for cell in row):
            continue

        raw: Dict[str, Any] = {}
        for idx, value in enumerate(row):
            if idx >= len(headers_norm):
                continue
            key = headers_norm[idx]
            if key:
                raw[key] = value

        # ---- BARCODE (mandatory) ----
        barcode_raw = raw.get("barcode")
        barcode = normalize_barcode(barcode_raw)
        if not barcode:
            errors += 1
            continue

        # ---- ARTICLE NAME (mandatory) ----
        article_name_raw = raw.get("article_name")
        article_name_clean = normalize_name(article_name_raw)
        if not article_name_clean:
            errors += 1
            continue

        # Build data dict only with columns that exist on the model
        data: Dict[str, Any] = {}
        for k, v in raw.items():
            if k in model_columns:
                data[k] = v

        # Force canonical fields
        data["barcode"] = barcode
        data["article_name"] = article_name_clean

        # Auto weight detection from article_name if model has "size" column
        value, unit = parse_weight(article_name_clean)
        if value and unit and ("size" in model_columns) and not data.get("size"):
            data["size"] = f"{value} {unit}"

        # ===========================================================
        # CASE A / B → Barcode already exists in PKB
        # ===========================================================
        if barcode in barcode_map:
            existing = barcode_map[barcode]
            changed = False

            for field, new_value in data.items():
                old_value = getattr(existing, field, None)

                # Both None / both empty / equal as string → no change
                if (
                    (old_value is None and new_value is None)
                    or (str(old_value).strip() == str(new_value).strip())
                ):
                    continue

                # FIELD CHANGED → CASE B
                setattr(existing, field, new_value)
                _log_update(
                    db=db,
                    pkb_id=existing.pkb_id,
                    field=field,
                    old_value=old_value,
                    new_value=new_value,
                    reason="FIELD_CHANGED",
                )
                changed = True

            if changed:
                updated += 1
            else:
                # CASE A → Everything same, no update
                skipped_case_a += 1

            # Done with this row
            continue

        # ===========================================================
        # CASE C → New barcode, but same article_name already exists
        # ===========================================================
        normalized_name = normalize_name(article_name_clean)
        if normalized_name in name_map:
            base_product = name_map[normalized_name]

            new_item = PKBProduct(**data)
            db.add(new_item)
            db.flush()  # assign pkb_id

            # Log duplicate relationship
            _log_update(
                db=db,
                pkb_id=new_item.pkb_id,
                field="duplicate_of",
                old_value=base_product.pkb_id,
                new_value=new_item.barcode,
                reason="DUPLICATE_BARCODE_SAME_NAME",
            )

            # Update maps
            barcode_map[barcode] = new_item
            name_map[normalized_name] = base_product  # base remains same reference

            case_c_created += 1
            continue

        # ===========================================================
        # NEW PRODUCT (unique barcode + unique article_name)
        # ===========================================================
        new_item = PKBProduct(**data)
        db.add(new_item)
        db.flush()

        barcode_map[barcode] = new_item
        name_map[normalize_name(article_name_clean)] = new_item

        inserted += 1

    # Commit all changes
    db.commit()

    return {
        "inserted": inserted,
        "updated": updated,
        "case_c_created": case_c_created,
        "case_a_skipped": skipped_case_a,
        "errors": errors,
        "total_rows": len(rows) - 1,
        "message": "PKB import completed",
    }
