from sqlalchemy import Column, Integer, String, Numeric, Boolean, DateTime, Text, func
from sqlalchemy.orm import relationship
from app.models.base import Base


class PKBProduct(Base):
    __tablename__ = "pkb_products"

    pkb_id = Column(Integer, primary_key=True, index=True)

    # ----------------------------
    # FULL PKB STRUCTURE (Excel)
    # ----------------------------

    remarks = Column(Text, nullable=True)  # non-mandatory
    category_6 = Column(String(150), nullable=False)  # mandatory

    barcode = Column(String(50), unique=True, nullable=False, index=True)
    supplier_name = Column(String(150), nullable=False)
    hsn_code = Column(String(20), nullable=False)

    division = Column(String(100), nullable=False)
    section = Column(String(100), nullable=False)
    department = Column(String(100), nullable=False)

    article_name = Column(String(255), nullable=False)  # mandatory
    item_name = Column(String(255), nullable=True)      # non-mandatory
    product_name = Column(String(255), nullable=True)   # Excel NAME column

    brand_name = Column(String(150), nullable=True)
    size = Column(String(100), nullable=True)

    weight = Column(String(50), nullable=True)  # extracted automatically

    rsp = Column(Numeric(10, 2), nullable=False)
    mrp = Column(Numeric(10, 2), nullable=False)

    # ----------------------------
    # TAX DETAILS (optional)
    # ----------------------------
    cgst = Column(Numeric(10, 2))
    sgst = Column(Numeric(10, 2))
    cess = Column(Numeric(10, 2))
    igst = Column(Numeric(10, 2))
    tax = Column(Numeric(10, 2))

    # ----------------------------
    # SYSTEM FIELDS
    # ----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)

    # ----------------------------
    # RELATIONSHIPS
    # ----------------------------
    update_logs = relationship("PKBUpdateLog", back_populates="product", cascade="all, delete-orphan")
